const input = document.getElementById("imageInput");
const chooseBtn = document.getElementById("chooseBtn");
const dropZone = document.getElementById("dropZone");
const fileName = document.getElementById("fileName");
const detectBtn = document.getElementById("detectBtn");
const confidence = document.getElementById("confidence");
const confidenceValue = document.getElementById("confidenceValue");
const loading = document.getElementById("loading");
const errorBox = document.getElementById("errorBox");
const resultsSection = document.getElementById("resultsSection");
const resultImage = document.getElementById("resultImage");
const detectionList = document.getElementById("detectionList");
const totalBadge = document.getElementById("totalBadge");
const newScanBtn = document.getElementById("newScanBtn");

let selectedFile = null;

chooseBtn.addEventListener("click", () => input.click());
dropZone.addEventListener("click", (e) => {
    if (e.target !== chooseBtn) input.click();
});

input.addEventListener("change", () => {
    if (input.files.length) setFile(input.files[0]);
});

["dragenter", "dragover"].forEach(eventName => {
    dropZone.addEventListener(eventName, e => {
        e.preventDefault();
        dropZone.classList.add("dragover");
    });
});

["dragleave", "drop"].forEach(eventName => {
    dropZone.addEventListener(eventName, e => {
        e.preventDefault();
        dropZone.classList.remove("dragover");
    });
});

dropZone.addEventListener("drop", e => {
    const file = e.dataTransfer.files[0];
    if (file) setFile(file);
});

confidence.addEventListener("input", () => {
    confidenceValue.textContent = confidence.value;
});

function setFile(file) {
    const allowed = ["image/jpeg", "image/png", "image/webp"];
    if (!allowed.includes(file.type)) {
        showError("Please select a JPG, PNG or WEBP image.");
        return;
    }

    selectedFile = file;
    fileName.textContent = file.name;
    detectBtn.disabled = false;
    hideError();
}

detectBtn.addEventListener("click", async () => {
    if (!selectedFile) return;

    const formData = new FormData();
    formData.append("image", selectedFile);
    formData.append("confidence", Number(confidence.value) / 100);

    setLoading(true);
    hideError();

    try {
        const response = await fetch("/predict", {
            method: "POST",
            body: formData
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            throw new Error(data.error || "Detection failed.");
        }

        resultImage.src = data.result_url + "?t=" + Date.now();
        totalBadge.textContent =
            `${data.total} detection${data.total === 1 ? "" : "s"}`;

        renderDetections(data.detections);
        resultsSection.classList.remove("hidden");
        resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (error) {
        showError(error.message);
    } finally {
        setLoading(false);
    }
});

function renderDetections(detections) {
    detectionList.innerHTML = "";

    if (!detections.length) {
        detectionList.innerHTML =
            '<div class="empty">No damage detected above the selected confidence threshold.</div>';
        return;
    }

    detections.forEach((item, index) => {
        const div = document.createElement("div");
        div.className = "detection-item";
        div.innerHTML = `
            <div class="detection-top">
                <span class="class-name">${index + 1}. ${escapeHtml(item.class)}</span>
                <span class="confidence">${item.confidence}%</span>
            </div>
            <div class="empty">
                Bounding box: (${item.box.x1}, ${item.box.y1}) →
                (${item.box.x2}, ${item.box.y2})
            </div>
        `;
        detectionList.appendChild(div);
    });
}

newScanBtn.addEventListener("click", () => {
    resultsSection.classList.add("hidden");
    selectedFile = null;
    input.value = "";
    fileName.textContent = "";
    detectBtn.disabled = true;
    window.scrollTo({ top: 0, behavior: "smooth" });
});

function setLoading(active) {
    loading.classList.toggle("hidden", !active);
    detectBtn.disabled = active || !selectedFile;
    detectBtn.textContent = active ? "Detecting..." : "Detect Damage";
}

function showError(message) {
    errorBox.textContent = message;
    errorBox.classList.remove("hidden");
}

function hideError() {
    errorBox.classList.add("hidden");
}

function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;",
        '"': "&quot;", "'": "&#039;"
    }[char]));
}
